/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe528.project;

/**
 *
 * @author Dskam
 */
public abstract class levels {
    
    protected String l;
    
    public levels(String l){
        this.l = l;
    }
    
        @Override
    public String toString(){//overriding the toString() method
        return l;
    }
    
    public abstract void setTheLevel(Customer c);
    

}
