/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe528.project;

import java.io.FileNotFoundException;

/**
 *
 * @author Dskam
 */
public class silver extends levels {

    public silver(String l) {
        super(l);
    }
    
    
    @Override
    public void setTheLevel(Customer c) {
       double amount; 
        try {
            amount = c.changeBalanceToDouble();
            
            if(amount < 10000){
            c.setLevel(new silver("Silver"));  
        }
        
        if(amount >= 10000 && amount < 20000){
            c.setLevel(new gold("Gold"));
        }
        
        if(amount >= 20000){
            c.setLevel(new platinum("Platinum"));
        }
    
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
               
        
    }
    
}
