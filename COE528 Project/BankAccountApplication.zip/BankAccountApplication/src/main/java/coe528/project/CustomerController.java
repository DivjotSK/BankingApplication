/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package coe528.project;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;


/**
 * FXML Controller class
 *
 * @author Dskam
 */
public class CustomerController implements Initializable {

    @FXML
    private Button logout;
    
    @FXML
    private ListView<String> List;
    @FXML
    private ComboBox<String> dropdown;
    @FXML
    private TextField Transaction;
    @FXML
    private Button Enter;
    @FXML
    private Text accountBalance;
    @FXML
    private ImageView balance;
    
    private Customer c;
    
    
    @FXML
    private Text accountName;
    @FXML
    private Text level;
    @FXML
    private Label invalidTransactionLabel;
    
    private static ObservableList<String> transactions = FXCollections.observableArrayList();
    


    /**
     * Initializes the controller class.
     */
    
    public void setCustomer(Customer customer) throws FileNotFoundException{
        c = customer;
        printBalance();
        printName();
        printLevel();
       updateTransactions();
    }
    
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb){
        dropdown.getItems().addAll("withdraw", "deposit", "online purchase");
        invalidTransactionLabel.setText("");

        
    }    

    @FXML
    private void clickedLogout(ActionEvent event) throws IOException {
        
        App.setRoot("primary");
        
        
        
    }
    

    
    private void printBalance() throws FileNotFoundException {
        
        System.out.println(Customer.checkBalance(c.getUsername()));
        accountBalance.setText(String.format("%.2f",  Customer.checkBalance(c.getUsername())));
       
    }
   
    
    private void printName() throws FileNotFoundException{
        accountName.setText(c.getUsername());
    }
    
    private void printLevel() throws FileNotFoundException{
        c.setLevel();
        levels l = c.getLevel();
        l.setTheLevel(c);
        level.setText(Customer.getCustomer().getLevel().toString());
        System.out.println(l);
    }
    
private void updateTransactions() throws FileNotFoundException {
        
        File history = new File("src/main/java/coe528/projectTransactions/" + c.getUsername() + "Transaction.txt");
        if(history.exists()){
            Scanner sc = new Scanner(history);
            while (sc.hasNextLine()) {
                transactions.add(sc.nextLine());
            }
            sc.close();
            List.setItems(transactions);
        }
        
    }

private void updateTransactions(String t) throws FileNotFoundException {
    transactions.add(t);
    List.setItems(transactions);
}
    
    private void deposit() throws FileNotFoundException, IOException{

        double t = Double.parseDouble(Transaction.getText());
        
        if(t > 0){
            String temp = Customer.getCustomer().depositM(c.getUsername(), t);
            printBalance();
            printLevel();
            updateTransactions(temp);
            
        }
        
        else{
            invalidTransactionLabel.setText("Invalid deposit Amount");
        }
       
    }
    
        private void withdraw() throws FileNotFoundException, IOException{


        double t = Double.parseDouble(Transaction.getText());
        System.out.println(Customer.getCustomer().changeBalanceToDouble(c));
        
        if(t <= Customer.getCustomer().changeBalanceToDouble(c) && t > 0){
            String temp = Customer.getCustomer().withdrawM(c.getUsername(), t);
            printBalance();
            printLevel();
            updateTransactions(temp);
            
        }
        
        else if (t < 0){
            invalidTransactionLabel.setText("Invalid deposit Amount");
        }
        
        else{
            invalidTransactionLabel.setText("Invalid deposit Amount");
        }
        
        
    }
        
        private void onlinePurchase() throws FileNotFoundException, IOException{
            double t = Double.parseDouble(Transaction.getText());
            
            if(t >= 50){
                String temp = Customer.getCustomer().onlinePurchaseM(c.getUsername(), t);
                printBalance();
                
            
                if(!(temp.equals("heyyy"))){
                    updateTransactions(temp);
                    System.out.println("if wagwan");
               }
                else if(temp.equals("heyyy")){
                    invalidTransactionLabel.setText("Online purchase is invalid");
                    System.out.println("elseif Wagwan");
                    
                }
                
                else{
                    invalidTransactionLabel.setText("Online purchase is invalid");
                    System.out.println("else wagwan");
                }
                
               
            }
            
            else{
                invalidTransactionLabel.setText("Online purcahses must be atleast $50");
                
            }
            
            
        }


    
    @FXML
    private void clickedEnter(ActionEvent event) throws FileNotFoundException, IOException {
         
        String temp = dropdown.getValue();
        invalidTransactionLabel.setText("");
         
        if(temp.equals("deposit")){
            deposit();
        }
        
        else if(temp.equals("withdraw")){
            withdraw();
        }
        
        else if(temp.equals("online purchase")){
            onlinePurchase();
        }
        
        printLevel();
    }

    
}
