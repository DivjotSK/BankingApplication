package coe528.project;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;


public class PrimaryController{

    @FXML
    private Button loginButton;
    
    @FXML
    private PasswordField password;

    @FXML
    private TextField username;
    @FXML
    private Label invalidLoginLabel;

    @FXML
    void clickLoginButton(ActionEvent event) throws IOException {
       
        if(Manager.getManager().login(username.getText(), password.getText())){
            App.setRoot("secondary");
       } 
        else if(Customer.login(username.getText(), password.getText())){
            Customer temp = new Customer(username.getText(), password.getText(), "customer");
            
           
            
           FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("customer.fxml"));
           Parent root = (Parent)fxmlLoader.load();
           CustomerController controller = fxmlLoader.<CustomerController>getController();
           controller.setCustomer(temp);
           App.setRoot(root);
           
        }
        
        else{
            invalidLoginLabel.setText("Invalid username/password");
        }
    } 
}