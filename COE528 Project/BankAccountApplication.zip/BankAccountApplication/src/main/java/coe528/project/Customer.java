/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe528.project;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
/**
 *
 * @author Dskam
 */
public class Customer extends user {
    
//    private user temp;
    private String username;
    private static Customer customer = null;
    private static levels currentLevel;
    private ArrayList <String> transactions;
    
    
    
    public Customer(String username, String password, String role) {
        super(username, password, role);
        this.username = username;
        this.transactions = new ArrayList<>();
        
    }
    
    public static boolean login(String username, String password) throws IOException{
        File file = new File("src/main/java/coe528/projectFiles/" + username + ".txt");

        if(file.exists()) {
            String[] split;
            try (Scanner scanner = new Scanner(file)) {
                split = scanner.nextLine().split(",");
                System.out.println(split[0]);
                System.out.println(split[1]);
                System.out.println(split[2]);
            }
            if (username.equals(split[0]) && password.equals(split[1])){
                
                return true;
            }
            
        }
        
        return false;     
    }
    
    
    public static double checkBalance(String username) throws FileNotFoundException{
         File file = new File("src/main/java/coe528/projectFiles/" + username + ".txt");

        if(file.exists()) {
            Scanner scanner = new Scanner(file);
            String[] split = scanner.nextLine().split(",");
            scanner.close();
            return Double.parseDouble(split[2]);
            
        }
        
        return 0;
    }
    
    public double changeBalanceToDouble() throws FileNotFoundException{
        double balance = checkBalance(username);
        return balance;
    }
    
      public double changeBalanceToDouble(Customer temp) throws FileNotFoundException{
        double balance = checkBalance(temp.getUsername());
        return balance;
    }
    
    public String getUsername(){
            return username;
        }
    
    public String depositM(String username, double transaction) throws FileNotFoundException, IOException{
            
        
            double Amount = checkBalance(username);
            
            if(transaction > 0){
                transactionHistory(username,"deposit " + String.valueOf(transaction));
                Amount = Amount + transaction;
                fileWriting(username, Amount);
               
                return "deposit " + String.valueOf(transaction);
            }
            
            else{
                System.out.println("not valid deposit");
                return null;
            }
        
    }
    
        public String withdrawM(String username, double transaction) throws FileNotFoundException, IOException{
            
            double Amount = checkBalance(username);
            
            if(transaction <= Amount && transaction > 0){
                transactionHistory(username,"withdraw " + String.valueOf(transaction));
                Amount = Amount - transaction;
                fileWriting(username, Amount);
                
                return "withdraw " + String.valueOf(transaction);
            }
            
            else{
                System.out.println("not valid withdrawal");
                return null;
            }
            
           
        
    }
        
       public String onlinePurchaseM(String username, double transaction) throws FileNotFoundException, IOException{
           
           double Amount = checkBalance(username);
           String currLevel = Customer.getCustomer().getLevel().toString();
           
           
           if(transaction >= 50){
               if(currLevel.equals("Silver") && Amount >= transaction + 20){
                   transactionHistory(username,"online purchase " + String.valueOf(transaction + 20));
                   Amount = Amount - transaction - 20;
                   fileWriting(username, Amount);
                   return "online purchase " + String.valueOf(transaction + 20);
               }
               
               else if(currLevel.equals("Gold") && Amount >= transaction + 10){
                   transactionHistory(username,"online purchase " + String.valueOf(transaction + 10));
                   Amount = Amount - transaction - 10;
                   fileWriting(username, Amount);
                   return "online purchase " + String.valueOf(transaction + 10);
               }
               
                   else if(currLevel.equals("Platinum") && transaction <= Amount){
                   transactionHistory(username,"online purchase " + String.valueOf(transaction));
                   Amount = Amount - transaction;
                   fileWriting(username, Amount);
                   return "online purchase " + String.valueOf(transaction);
               }
               
               System.out.println("Online purchase must be atleat $50");
               
           
           }
           
           
               System.out.println("Purchase must be atleat $50");
                return ("heyyy");
       }
       
       public void transactionHistory(String user, String list) throws IOException {
        File history = new File("src/main/java/coe528/projectTransactions/" + user + "Transaction.txt");
        if(history.createNewFile()) {
            FileWriter fr = new FileWriter(history, true);
            fr.write(list);
            fr.close();
        } else {
            FileWriter fr = new FileWriter(history, true);
            fr.write("\n" + list);
            fr.close();
        }
    }

       

        
        
        public void fileWriting(String username, double transaction) throws FileNotFoundException, IOException {
            
            
            
            File file = new File("src/main/java/coe528/projectFiles/" + username + ".txt");
              Scanner scanner;
              scanner = new Scanner(file);
              String[] split = scanner.nextLine().split(",");
              scanner.close();
            try (FileWriter f2 = new FileWriter(file, false)) {
   
            f2.write(username + "," + split[1] + "," + transaction + ",customer," + "\n");
        
            f2.close();
        }

    }  
        
        public static Customer getCustomer() {
        if (customer == null) {
            customer = new Customer("", "", "Customer");
        }
        return customer;
    }
        
        
        public void setLevel() throws FileNotFoundException {
        if (changeBalanceToDouble() < 10000) {
           currentLevel = new silver("SILVER"); 
        } else if (changeBalanceToDouble() > 10000 && changeBalanceToDouble() < 20000) {
            currentLevel = new gold("GOLD"); 
        } else {
           currentLevel = new platinum("PLATINUM");
        }
    }
        
        public void setLevel(levels level){
            currentLevel = level;
        }
        
        public static levels getLevel(){
            return currentLevel;
        }
    
    
    
}
