/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe528.project;

/**
 *
 * @author Dskam
 */

/*
    Overview:User is a mutable object that defines the type of user using the software which includes manager or customer
    Abstration Function: The user creates an object which represents a user of the software. Each object has an Username, Password for all users and their role within the program in a file.
    Rep Invariant: For all users the username, password, and role are Strings which are neither blank or null.
*/
public abstract class user {
    protected String username;
    protected String password;
    protected String role;
    
    //Effects: initializes instance variables of this using given parameters
    //Modifiers: sets variables in parameters to corresponding instance variables
    //Requiers: Requires three parameteres which include username, password, role
    public user(String username, String password, String role){
        this.username = username;
        this.password = password;
        this.role = role;
    }
    
    //Effects:returns username
    //Modifiers:none
    //Requiers:none
    public String getUsername(){
        return username;
    }
    
    //Effects:changes the objects password
    //Modifiers: changes objects password to the new password given
    //Requiers:a String variable called username
    public void setUsername(String username){
        this.username = username;
    }
    
     //Effects:returns password
    //Modifiers:none
    //Requiers:none
    public String getPassword(){
        return password;
    }
    
    //Effects:changes the objects password
    //Modifiers: changes objects password to the new password given
    //Requiers:a String variable called password
    public void setPassoword(String password){
        this.password = password;
    }
    
    //Effects:returns role
    //Modifiers:none
    //Requiers:none
    public String getRole(){
        return this.role;
    }
    
    //Effects:changes the objects password
    //Modifiers: changes objects password to the new password given
    //Requiers:a String variable called role
    public void setRole(String role){
        this.role = role;
    }
    
    //Effects:returns password, username, and role in toString method
    //Modifiers:none
    //Requiers:none
    @Override
    public String toString(){
        return "Username: " + username + ", Password: " + password + ", Role: " + role; 
    }

    //Effects:Checks if username, password, or role is either blank or null
    //Modifiers:None
    //Requiers:None
    public boolean replOk(){
        if(username.isBlank()  || password.isBlank() || role.isBlank() || username == null || password == null || role == null){
            return false;
        }
        return true;
    }
    
    
    

}
