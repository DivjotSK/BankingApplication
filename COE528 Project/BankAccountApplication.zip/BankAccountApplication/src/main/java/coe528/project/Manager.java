/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package coe528.project;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Dskam
 */
public class Manager extends user {
    
    private static Manager m = null;
     
    public Manager() {
        super("admin", "admin", "manager");
        
    }
    
    public static Manager getManager() {
        if (m == null) {
            m = new Manager();
        }
        
        return m;
    }
    
        protected boolean login(String username, String password) throws IOException{

            if (username.equals("admin") && password.equals("admin")){
                return true;
            }

            else{
                return false;
            }

        }
        
       
        
       public void createCustomer(String username, String password) throws IOException{
    
            try {
                File myObj = new File("src/main/java/coe528/projectFiles/"+username + ".txt");
                if (myObj.createNewFile()) {
                    System.out.println("File created: " + myObj.getName());
                    FileWriter fr = new FileWriter(myObj, true);
                    fr.write(username + "," + password + ",100,customer");
                    fr.close();
                } 
                
                else {
                    System.out.println("File already exists.");
                }
            } 
            
            catch (IOException e) {
                System.out.println("An error occurred.");
               // e.printStackTrace();
            }
         
        }
        
        public void deleteCustomer(String username) throws IOException, FileNotFoundException {
            File f = new File ("src/main/java/coe528/projectFiles/" + username +".txt");
            File f2 = new File ("src/main/java/coe528/projectTransactions/" + username +"Transaction.txt");
            if (f.exists() || f2.exists()) {
                System.out.println("File Exist");
                f.delete();
                f2.delete();
                    System.out.println("File delete");
                
                
            }
            
            
            
            
           
            
        }
        
        public ArrayList<String> customerNames() throws FileNotFoundException {
        ArrayList<String> names = new ArrayList<>();
       
        File[] f = new File ("src/main/java/coe528/projectFiles/").listFiles();
        Scanner scanner;
        
        for (int i = 0; i < f.length; i++) {
            scanner = new Scanner(f[i]);
            String[] split = scanner.nextLine().split(",");
            names.add(split[0]);
            scanner.close();
        }
      
        return names;



    }
       
        
                
   }
        
    

    

