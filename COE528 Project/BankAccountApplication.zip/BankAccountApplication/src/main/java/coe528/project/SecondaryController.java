package coe528.project;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.lang.String;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;


public class SecondaryController implements Initializable{
     
    private ArrayList<String>temp;
     
    
    @FXML
    private Button addAccount;
    
    @FXML
    private Button delete;

    @FXML
    private Button logout;

    @FXML
    private TextField addPassword;

    @FXML
    private TextField addUsername;
    @FXML
    private ComboBox<String> comboBox;
    @FXML
    private Label deletedLabel;
    @FXML
    private Label notAddedLabel;
    @FXML
    private Label accountAddedLabel;
    

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        temp = new ArrayList<>(); 
        setData();
         
    }   
    
    private void setData(){
      // if (!comboBox.getItems().isEmpty()) {
           comboBox.getItems().clear();
        try {
            
            temp = Manager.getManager().customerNames();
            
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        comboBox.getItems().addAll(temp);
       }
        
    //}
    
    @FXML
    void clickedDelete(ActionEvent event) throws IOException {
       accountAddedLabel.setText("");
       notAddedLabel.setText("");
        
        String user = comboBox.getSelectionModel().getSelectedItem();
        
        Manager.getManager().deleteCustomer(user);
        setData();
        
        deletedLabel.setText("Deleted sucessfully");
           
      
    }

    @FXML
    void clickedLogout(ActionEvent event) throws IOException {
        App.setRoot("primary");
    }
    
    @FXML
    void  addAccountClicked(ActionEvent event) throws IOException{
       deletedLabel.setText("");
       accountAddedLabel.setText("");
       notAddedLabel.setText("");
       if ((addPassword.getText() == null) || addUsername.getText().trim().isEmpty() || addPassword.getText() == null || addPassword.getText().trim().isEmpty()) {
            notAddedLabel.setText("only enternumbers/letters");
    }
       
       else{
           
       
        if(addPassword.getText().matches("^[a-zA-z0-9]*$")&& addUsername.getText().matches("^[a-zA-z0-9]*$")) {
        
            Manager.getManager().createCustomer(addUsername.getText(), addPassword.getText());
            setData();
            
            accountAddedLabel.setText("Account added successfully");
        }
        
        else{
            notAddedLabel.setText("only enternumbers/letters");
        }
       } 
        
    }

   


}
